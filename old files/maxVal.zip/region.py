
class Region:

    def __init__(self,regoin_function,boundry):
        assert len(regoin_function)-1 == len(boundry), "Region function and boundry do not match"
        self.regoin_function=regoin_function
        self.boundry=boundry

    def getMaxValue(self):
        value = 0
        point=[]

        for i in range(len(self.boundry)):
            if self.regoin_function[i]>0:
                value += self.regoin_function[i]*max(self.boundry[i])
                point.append(max(self.boundry[i]))
            else:
                value += self.regoin_function[i]*min(self.boundry[i])
                point.append(min(self.boundry[i]))

        return value,point

    def getMidPoint(self):
        return [sum(i)/2 for i in self.boundry]

    def getDistanceToBoundry(self):
        distance=[]
        midpoint=self.getMidPoint()

        for i in range(len(midpoint)):
        
            tmp_vector = [self.boundry[i][0] if i==j else 0 for j in range(len(midpoint))]
            vector = [midpoint[i]-tmp_vector[i] for i in range(len(midpoint))]
            distance.append(sum([j**2 for j in vector])/len(vector))
        return distance
